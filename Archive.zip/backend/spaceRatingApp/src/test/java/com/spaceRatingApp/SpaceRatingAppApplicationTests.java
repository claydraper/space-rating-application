package com.spaceRatingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpaceRatingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
