# space-rating-application
A full stack application utilizing Java, Spring Boot, MySQL, and React
